Guide: https://towardsdatascience.com/data-science-skills-web-scraping-javascript-using-python-97a29738353f

Install:

Firefox Geckodriver: https://github.com/mozilla/geckodriver/releases
    Download latest driver
    move geckodriver file to executable path
pip3 install selenium
pip3 install bs4
