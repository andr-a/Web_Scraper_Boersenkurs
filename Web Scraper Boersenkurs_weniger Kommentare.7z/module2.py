from tkinter import messagebox
import time
import datetime

disabled = False


# Modul-Methoden
def check_isin_format(isin):
    if len(isin) == 12:
        return True
    else:
        messagebox.showerror("Falsches ISIN Format", "Die ISIN muss 12 Zeichen haben.")
        return False


def check_day_time():
    d = datetime.datetime.now()
    if d.isoweekday() in range(1, 6) and d.hour in range(8, 20):
        return True
    else:
        return False
